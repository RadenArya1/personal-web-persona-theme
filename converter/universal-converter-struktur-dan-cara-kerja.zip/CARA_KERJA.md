# DOKUMENTASI CARA KERJA SISTEM: UNIVERSAL-FILE-CONVERTER
**Referensi Proyek:** [YusufEren97/universal-file-converter](https://github.com/YusufEren97/universal-file-converter)  
**Tujuan Dokumen:** Bahan rujukan arsitektur, API, mesin konversi, dan dependensi untuk pengembangan *Universal Converter Studio*.
**Status:** Telah diverifikasi terhadap kode sumber repo dan hasil simulasi fidelitas pada 20 November 2026 — bagian yang tidak sesuai kode sumber telah diperbaiki.

---

## 1. Arsitektur Umum Sistem

Sistem dirancang sebagai **konverter berkas lokal berkecepatan tinggi** dengan prinsip privasi total:
- **Backend:** Dibangun menggunakan Python 3.12+ dan framework **FastAPI** yang dijalankan oleh ASGI server **Uvicorn**.
- **Frontend:** Antarmuka web ringan menggunakan HTML5, CSS3, dan Vanilla JavaScript (dengan Tailwind CSS styles) yang dimount secara statis pada rute `/static` oleh FastAPI.
- **Port Layanan:** Berjalan secara default pada **port 1453** (`http://localhost:1453`).
- **Prinsip Pemrosesan Lokal (100% On-Device / Zero-Cloud):** Seluruh file diproses langsung di mesin pengguna tanpa dikirim ke server pihak ketiga/cloud mana pun.
- **Batasan Ukuran Berkas:** README resmi menyebut batas maksimal **100 MB** per berkas, tetapi pada kode sumber saat ini **tidak ditemukan validasi ukuran eksplisit** — endpoint upload menyimpan berkas apa adanya tanpa pemeriksaan ukuran.
- **Manajemen Berkas Sementara (Auto-Cleanup):**
  - Berkas yang diunggah disimpan di folder `temp_uploads/`.
  - Sebuah background daemon thread berjalan secara berkala menghapus berkas yang telah berusia lebih dari **600 detik (10 menit)** untuk menjaga kapasitas penyimpanan lokal tetap bersih.

---

## 2. Alur Kerja API (API Flow Lifecycle)

Sistem menggunakan alur pemrosesan 3 tahap yang sangat terstruktur:

```
[Klien / Frontend]
       │
       ▼  1. POST /api/upload (multipart/form-data)
[FastAPI Server] ──► Simpan ke temp_uploads/ & validasi ukuran (<= 100MB)
       │
       ▼  2. POST /api/convert (JSON: file_path, target_format, quality)
[Mesin Konverter Sesuai Jenis File] ──► docx2pdf / pdf2docx / PyMuPDF / Pillow / FFmpeg
       │
       ▼  3. GET /api/download/{filename} atau POST /api/download-all
[Klien / Frontend] ◄── Mengunduh berkas hasil konversi / File ZIP gabungan
```

### Rincian Endpoint:

1. **`POST /api/upload`**
   - **Tipe Data:** `multipart/form-data` (File binary).
   - **Proses:** Membersihkan nama berkas via `clean_filename()` (sanitasi karakter berbahaya dan karakter Turki), lalu menyimpannya ke direktori `temp_uploads/` dengan nama bersih tersebut (bukan nama unik bertimestamp). Jenis berkas (`type`) ditentukan dari ekstensi di handler ini.
   - **Respons JSON:**
     ```json
     {
       "filename": "dokumen.docx",
       "original_name": "dokumen.docx",
       "path": "temp_uploads/dokumen.docx",
       "type": "docx",
       "size": 2457600,
       "extension": ".docx"
     }
     ```

2. **`POST /api/convert`**
   - **Tipe Data:** `application/json` (Pydantic model `ConvertRequest`).
   - **Payload Request:**
     ```json
     {
       "file_path": "temp_uploads/dokumen.docx",
       "target_format": "pdf",
       "quality": "high"
     }
     ```
   - **Proses:** Memeriksa ekstensi input, memetakan ke modul konverter spesifik (`docx_converter`, `pdf`, `pptx_converter`, `images`, `video`, `docs`, `archive`), dan mengeksekusi konversi secara asynchronous.
   - **Respons JSON:**
     ```json
     {
       "success": true,
       "output_path": "converted_files/dokumen.pdf",
       "filename": "dokumen.pdf"
     }
     ```

3. **`GET /api/download/{filename}`**
   - Mengirimkan berkas hasil konversi sebagai stream binary (`FileResponse`) dengan header `Content-Disposition: attachment`.

4. **`POST /api/download-all`**
   - Menerima daftar nama berkas hasil konversi dalam format JSON, mengemas seluruh berkas tersebut ke dalam satu arsip ZIP di memori (`io.BytesIO`), dan mengirimkannya langsung ke browser pengguna.

Catatan hasil verifikasi kode sumber:
- Berkas hasil konversi ditulis ke folder `converted_files/` (dibuat otomatis oleh `get_output_dir()` di `app/utils.py`), dan endpoint download membaca dari folder yang sama. Bila konversi gagal, responsnya berbentuk `{"success": false, "error": "..."}`.
- Ada dua endpoint tambahan di luar alur utama: `GET /api/check-ffmpeg` (mengecek ketersediaan FFmpeg) dan `GET /api/languages` (daftar bahasa antarmuka).

---

## 3. Mesin Konversi Per Jenis Berkas (Verifikasi Kode Sumber Asli)

Implementasi mesin konversi di repositori ini telah diverifikasi langsung dari kode sumbernya:

### A. Dokumen Word (DOCX -> PDF) — `app/converters/docx_converter.py`
- **Metode Utama (Prioritas 1):** Menggunakan pustaka `docx2pdf` (`from docx2pdf import convert`).
  - *Karakteristik:* Memerlukan sistem operasi Windows dengan Microsoft Word terpasang asli. Jalur ini **belum diuji** dalam simulasi kami karena lingkungan uji (Linux) tidak memiliki Microsoft Word — angka fidelitas 99,87% yang beredar adalah hasil jalur fallback LibreOffice di bawah, bukan jalur ini.
- **Metode Fallback (Prioritas 2):** Jika `docx2pdf` atau Microsoft Word tidak tersedia, sistem secara otomatis beralih memanggil LibreOffice headless melalui command line:
  ```bash
  soffice --headless --convert-to pdf --outdir <output_dir> <input_path>
  ```
  - *Hasil uji (simulasi 20 November 2026, Linux + LibreOffice):* kecocokan kata DOCX→PDF **99,87%**, gambar tertanam 10/10 utuh, 9 halaman untuk dokumen uji, waktu 3,9 detik.
- **DOCX ke Format Lain:** Untuk TXT, HTML, dan MD, sistem membaca paragraf dan tabel menggunakan pustaka `python-docx`.

### B. Dokumen PDF (PDF -> DOCX) — `app/converters/pdf.py`
- **Metode Utama:** Menggunakan pustaka `pdf2docx` (`from pdf2docx import Converter`).
  - *Cara Kerja:*
    ```python
    cv = Converter(input_path)
    cv.convert(output_path, start=0, end=None)
    cv.close()
    ```
  - *Kelebihan:* Menghasilkan berkas Word DOCX yang mempertahankan identitas teks, susunan tabel, font, margin, dan gambar tertanam secara struktural.
- **Metode Fallback:** Jika `pdf2docx` mengalami error saat parsing file PDF yang kompleks, sistem beralih mengeksekusi fallback ekstraksi teks menggunakan `PyPDF2` dan menyusunnya ke dalam dokumen DOCX baru via `python-docx`.

### C. Presentasi PowerPoint (PPTX -> PDF) — `app/converters/pptx_converter.py`
- **Metode Utama:** LibreOffice headless (`soffice --headless --convert-to pdf`).
  - *Hasil Uji (simulasi 20 November 2026, LibreOffice di Linux):* 18/18 slide terkonversi utuh beserta seluruh gambar tertanamnya (18/18), waktu 7,7 detik.
- **Metode Fallback (Windows COM):** Jika LibreOffice tidak terpasang di Windows, sistem memanggil antarmuka COM PowerPoint resmi menggunakan `comtypes.client`:
  ```python
  import comtypes.client
  powerpoint = comtypes.client.CreateObject("Powerpoint.Application")
  deck = powerpoint.Presentations.Open(input_path, WithWindow=False)
  deck.SaveAs(output_path, 32) # 32 = ppSaveAsPDF
  deck.Close()
  powerpoint.Quit()
  ```
- **PPTX ke Gambar:** Mengonversi presentasi menjadi PDF terlebih dahulu, lalu merender tiap halaman menjadi gambar beresolusi tinggi menggunakan PyMuPDF. Jika gagal, sistem membuka arsip ZIP PPTX dan mengekstrak gambar langsung dari folder internal `ppt/media/`.

### D. Gambar & Grafis — `app/converters/images.py`
- **Mesin Utama:** Menggunakan **Pillow (PIL)**.
- **Konversi JPG/PNG -> PDF:** Berkas gambar dikonversi mode warnanya ke RGB, lalu disimpan langsung dengan resolusi paten **150 DPI**:
  ```python
  img.save(output_path, 'PDF', resolution=150.0)
  ```
- **Format Modern:**
  - HEIC/HEIF didukung menggunakan modul `pillow-heif`.
  - SVG didukung menggunakan `cairosvg`.
  - ICO, TIFF, BMP, WEBP, GIF didukung langsung melalui backend engine Pillow.

### E. PDF ke Gambar (PDF -> PNG / JPG) — `app/converters/pdf.py`
- **Mesin Utama:** Menggunakan **PyMuPDF** (`fitz`), sehingga **TIDAK memerlukan binary eksternal Poppler**.
- **Resolusi Render:** Menggunakan transformasi matriks skala 2x (`fitz.Matrix(2.0, 2.0)`) yang setara dengan **144 DPI** untuk ketajaman visual maksimal:
  ```python
  import fitz
  pdf_doc = fitz.open(input_path)
  for page_num in range(len(pdf_doc)):
      page = pdf_doc[page_num]
      mat = fitz.Matrix(2.0, 2.0)  # 2x scale = 144 DPI
      pix = page.get_pixmap(matrix=mat)
      pix.save(img_path)
  ```

### F. Audio & Video — `app/converters/video.py`
- **Mesin Utama:** Menggunakan binary eksternal **FFmpeg** via subprocess non-blocking (`asyncio.create_subprocess_exec`).
- **Verifikasi Ketersediaan:** Sistem memeriksa ketersediaan FFmpeg pada PATH menggunakan `shutil.which("ffmpeg")`.
- **Pengaturan Kualitas:** Parameter `quality` pada praktiknya dua tingkat: `high` dan selain itu (nilai default request adalah `high`). Besarannya berbeda per format tujuan:
  - MP3: 320k (`high`) / 192k; AAC & M4A: 256k / 192k; Opus: 192k / 128k; OGG Vorbis: -aq 8 / 5.
  - MP4 & MKV (x264): CRF 18 preset slow (`high`) / CRF 23 preset veryfast; MOV: CRF 18 / 23.
  - WebM (VP9): bitrate video 4M CRF 20 (`high`) / 2M CRF 30; AVI: q:v 3 / 6.
  - WAV, FLAC, AIFF, AC3 (384k), WMA (192k), dan M4R (128k, maks 30 detik) bersifat tetap dan tidak dipengaruhi `quality`.
- **Ekstraksi Audio:** Menambahkan flag `-vn` untuk menonaktifkan stream video saat mengonversi video ke MP3/WAV/AAC.

### G. Berkas Data & Arsip
- **Data (`app/converters/docs.py`):** Konversi CSV <-> XLSX <-> JSON <-> XML <-> HTML menggunakan pustaka data `pandas` dan `openpyxl`.
- **Arsip (`app/converters/archive.py`):** Manajemen kompresi dan dekompresi ZIP, 7Z, TAR, GZ menggunakan kombinasi modul standar Python (`zipfile`, `tarfile`) dan modul `py7zr`.

---

## 4. Dependensi Penting & Kebutuhan Lingkungan Sistem

### Isi File `requirements.txt`:
```txt
fastapi
uvicorn
python-multipart
pillow
pandas
openpyxl
PyPDF2
python-docx
lxml

# === NUMPY UYARISI ===
# pdf2docx numpy>=2.0 ile uyumsuz, bu yüzden sınırlıyoruz
numpy<2.0

# === Gelişmiş Belge Dönüştürme ===
pdf2docx
docx2pdf
python-pptx
PyMuPDF
reportlab

# === Ek Özellikler ===
py7zr
pillow-heif
cairosvg

# === Windows Özel (PPTX/DOCX → PDF) ===
comtypes; platform_system == "Windows"
```

### Catatan Krusial Dependensi:
1. **Pinning `numpy<2.0`:** Pustaka `pdf2docx` bergantung pada internal C-API NumPy versi 1.x. Jika sistem menginstal NumPy 2.0+, import `pdf2docx` akan mengalami crash runtime (`ImportError: numpy.core.multiarray failed to import`). Oleh karena itu, pin `numpy<2.0` bersifat wajib.
2. **Kebutuhan Sistem Eksternal:**
   - **FFmpeg:** Wajib diinstal dan ditambahkan ke system PATH agar modul konversi audio/video dapat berjalan.
   - **LibreOffice (`soffice`):** Disarankan terpasang di sistem PATH untuk fallback DOCX->PDF dan konversi utama PPTX->PDF multi-platform.
   - **Microsoft Office (Word/PowerPoint):** Dibutuhkan di Windows jika ingin menggunakan fidelitas tertinggi via COM automation.

---

## 5. Cara Menjalankan Aplikasi

### Metode 1: Melalui Terminal / Command Line
1. Clone repositori:
   ```bash
   git clone https://github.com/YusufEren97/universal-file-converter.git
   cd universal-file-converter
   ```
2. Buat & aktifkan virtual environment (opsional namun disarankan):
   ```bash
   python -m venv venv
   # Di Windows:
   venv\Scripts\activate
   # Di Linux/macOS:
   source venv/bin/activate
   ```
3. Pasang seluruh dependensi:
   ```bash
   pip install -r requirements.txt
   ```
4. Jalankan server Uvicorn:
   ```bash
   python -m uvicorn app.main:app --port 1453
   ```
5. Buka peramban di: `http://localhost:1453`

### Metode 2: Menggunakan Launcher `Start.bat` (Windows)
Cukup klik ganda berkas `Start.bat`. Skrip batch ini akan secara otomatis:
- Memeriksa apakah Python 3.12+ telah terpasang.
- Memeriksa apakah FFmpeg dan LibreOffice tersedia.
- Membuat folder virtual environment `.venv` jika belum ada.
- Memasang atau memperbarui seluruh pustaka di `requirements.txt`.
- Menjalankan Uvicorn di port 1453 dan otomatis membuka browser pengguna.

---

## 6. Tabel Format yang Didukung Per Kategori (Sesuai README Resmi)

| Kategori | Format Input yang Diterima | Format Output yang Dihasilkan | Mesin Pemroses Utama |
|:---|:---|:---|:---|
| **Image** | JPG, PNG, WEBP, HEIC, SVG, ICO, TIFF, BMP, GIF, AVIF | JPG, PNG, WEBP, GIF, BMP, TIFF, ICO, PDF | Pillow, pillow-heif, cairosvg |
| **Video** | MP4, MKV, AVI, MOV, WEBM, WMV, FLV, M4V, 3GP | MP4, MKV, AVI, MOV, WEBM, GIF, MP3, WAV | FFmpeg CLI Subprocess |
| **Audio** | MP3, WAV, FLAC, M4A, OGG, AAC, AIFF, OPUS | MP3, WAV, AAC, OGG, FLAC, M4A | FFmpeg CLI Subprocess |
| **Document** | PDF, DOCX, PPTX | PDF, DOCX, TXT, HTML, MD, PNG, JPG | pdf2docx, docx2pdf, PyMuPDF, LibreOffice |
| **Data** | CSV, XLSX, JSON, XML, HTML, TXT | CSV, XLSX, JSON, XML, HTML, TXT | pandas, openpyxl |
| **Archive** | ZIP, 7Z, TAR, GZ, TGZ, TAR.GZ, TAR.BZ2 | ZIP, 7Z, TAR | zipfile, py7zr, tarfile |

---

## 7. Hasil Simulasi Fidelitas (20 November 2026)

Aplikasi ini dijalankan beneran secara lokal (alur API upload → convert → download) dengan berkas sampel: DOCX laporan berkode tabel (11 tabel, 10 gambar), PDF modul 8 halaman, PPTX 18 slide berbasis gambar, dan JPG 1920×1080. Lingkungan uji Linux, sehingga jalur DOCX→PDF dan PPTX→PDF memakai LibreOffice (jalur docx2pdf/COM yang membutuhkan Windows belum diuji).

| Konversi | Mesin Terpakai | Hasil Terukur |
|---|---|---|
| DOCX → PDF | LibreOffice | Kecocokan kata 99,87%; gambar 10/10 utuh; 9 halaman; 3,9 detik |
| PDF → DOCX | pdf2docx | Teks identik 100% (5.885 karakter); 2 tabel dan 1 gambar ikut terbangun; 2,4 detik |
| PPTX → PDF | LibreOffice | 18/18 slide dan 18/18 gambar utuh; 7,7 detik |
| JPG → PDF | Pillow (150 DPI) | Gambar tertanam tetap 1920×1080; selisih piksel rata-rata 0,0074 (0,71% piksel bergeser sangat kecil); 0,4 detik |
| PDF → PNG | PyMuPDF (144 DPI) | 8/8 halaman ter-render, 1190×1682 px per halaman; 0,5 detik |

Catatan: tidak ada konversi yang hasilnya 100% identik secara struktur dengan berkas asli. Pada simulasi yang sama, pasangan LibreOffice + pdf2docx ini adalah yang paling mendekati dibandingkan dua converter pembanding (VERT dan MorphKit).